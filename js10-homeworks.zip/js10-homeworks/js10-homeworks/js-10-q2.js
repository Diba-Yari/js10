// Define any car using an object with 4 properties, like: car name, model, color and etc.
// Then access the car’s name value in the console with the way you’ve learned

//! Answer:

let car = {
  name: "BMW",
  model: "BMW iX M60",
  colors: ["black", "red", "gray"],
};

console.log(car.name);
